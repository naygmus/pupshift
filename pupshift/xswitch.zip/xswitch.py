# -*- coding: utf-8 -*-
"""X11-движок pupshift: захват горячей клавиши, чтение выделения (PRIMARY),
замена текста через XTest, переключение группы раскладок через XKB.

Потоковая модель: run() крутится в отдельном потоке и владеет X-соединением;
GTK-поток общается с ним через очередь команд (set_enabled/grab_async/set_group).
"""
import queue
import select
import time

from Xlib import X, XK, display
from Xlib.error import BadAccess, XError
from Xlib.ext import xtest

from .transform import has_cyrillic, to_latin, transform


def _dbg(*a):
    import os
    if os.environ.get("PUPSHIFT_DEBUG"):
        print("[pupshift]", *a, flush=True)


MOD_MASKS = {
    "shift": X.ShiftMask, "ctrl": X.ControlMask,
    "alt": X.Mod1Mask, "super": X.Mod4Mask,
}


def _lock_combinations():
    """Все комбинации Lock (CapsLock), Mod2 (NumLock), Mod5 (ScrollLock)."""
    combs = [0]
    for m in (X.LockMask, X.Mod2Mask, X.Mod5Mask):
        combs += [c | m for c in combs]
    return combs


LOCK_COMBS = _lock_combinations()
_INTERESTING = X.ShiftMask | X.ControlMask | X.Mod1Mask | X.Mod4Mask


class HotkeyBusy(Exception):
    pass


class CatchError:
    """Ловит первое X-ошибку заданного класса; остальные пробрасывает."""

    def __init__(self, exc_type):
        self.exc_type = exc_type
        self._error = None

    def __call__(self, error, request):
        if isinstance(error, self.exc_type):
            if self._error is None:
                self._error = error
            return None
        raise error

    def get_error(self):
        return self._error


class Switcher:
    def __init__(self, cfg, on_error=None):
        self.cfg = cfg
        self.on_error = on_error
        self.dpy = display.Display()
        self.root = self.dpy.screen().root
        self.sel_win = self.root.create_window(
            -100, -100, 1, 1, 0, depth=X.CopyFromParent,
            window_class=X.InputOutput, visual=X.CopyFromParent, event_mask=0)
        self._grabbed = []
        self._busy = False
        self._cmds = queue.Queue()
        self._layouts = []
        self._xkb = None

    # ---------- XKB: группы раскладок ----------
    def _xkb_conn(self):
        if self._xkb is None:
            from .xkb import Xkb
            self._xkb = Xkb()
        return self._xkb

    def refresh_layouts(self):
        from .xkb import get_layouts
        self._layouts = get_layouts()

    def layout_name(self, group):
        try:
            return self._layouts[group].upper()
        except (IndexError, TypeError):
            return "??"

    def group_count(self):
        return max(1, len(self._layouts))

    def current_group(self):
        try:
            return self._xkb_conn().get_group()
        except Exception:
            return None

    def set_group(self, group):
        self._cmds.put(("set_group", group))

    # ---------- горячая клавиша ----------
    def grab(self, key, mods):
        self.ungrab()
        kc = self._kc(key)
        if not kc:
            raise ValueError("неизвестная клавиша: %s" % key)
        mask = 0
        for m in mods or []:
            mask |= MOD_MASKS.get(m, 0)
        err = CatchError(BadAccess)
        for lock in LOCK_COMBS:
            self.root.grab_key(kc, mask | lock, False,
                               X.GrabModeAsync, X.GrabModeAsync, onerror=err)
        self.dpy.sync()
        if err.get_error() is not None:
            self.ungrab()
            raise HotkeyBusy("сочетание занято")
        self._grabbed = [(kc, mask | lock) for lock in LOCK_COMBS]

    def ungrab(self):
        for kc, m in self._grabbed:
            try:
                self.root.ungrab_key(kc, m)
            except XError:
                pass
        self._grabbed = []
        try:
            self.dpy.sync()
        except XError:
            pass

    def grab_async(self, key, mods):
        reply = queue.Queue()
        self._cmds.put(("grab", key, mods, reply))
        return reply.get(timeout=5)

    def set_enabled(self, on):
        self._cmds.put(("enabled", on))

    # ---------- цикл событий ----------
    def run(self):
        hk = self.cfg["hotkey"]
        try:
            self.grab(hk["key"], hk["mods"])
        except (HotkeyBusy, ValueError) as e:
            if self.on_error:
                self.on_error("Клавиша %s: %s" % (hk["key"], e))
        while True:
            try:
                self._drain_cmds()
                for ev in self._pump(0.15):
                    self._dispatch(ev)
            except XError as e:
                if self.on_error:
                    self.on_error("X11: %s" % e)
                time.sleep(1)

    def _drain_cmds(self):
        while True:
            try:
                cmd = self._cmds.get_nowait()
            except queue.Empty:
                return
            kind = cmd[0]
            if kind == "enabled":
                if cmd[1]:
                    hk = self.cfg["hotkey"]
                    try:
                        self.grab(hk["key"], hk["mods"])
                    except (HotkeyBusy, ValueError) as e:
                        if self.on_error:
                            self.on_error(str(e))
                else:
                    self.ungrab()
            elif kind == "set_group":
                try:
                    self._xkb_conn().lock_group(cmd[1])
                except Exception:
                    pass
            elif kind == "grab":
                _, key, mods, reply = cmd
                try:
                    self.grab(key, mods)
                    ok, err = True, None
                except (HotkeyBusy, ValueError) as e:
                    ok, err = False, str(e)
                reply.put((ok, err))

    def _pump(self, timeout):
        """Неблокирующее чтение событий; pop_event() тут не используется —
        его нет в старых версиях python-xlib, а pending_events() + next_event()
        есть всегда."""
        events = []
        n = self.dpy.pending_events()
        while n > 0:
            events.append(self.dpy.next_event())
            n -= 1
        if events:
            return events
        r, _, _ = select.select([self.dpy.fileno()], [], [], timeout)
        if r:
            events.append(self.dpy.next_event())
            n = self.dpy.pending_events()
            while n > 0:
                events.append(self.dpy.next_event())
                n -= 1
        return events

    def _dispatch(self, ev):
        if ev.type != X.KeyPress or not self._grabbed:
            return
        kc, mask = self._grabbed[0]
        if ev.detail != kc:
            return
        if (ev.state & _INTERESTING) != mask:
            return
        self.do_switch()

    # ---------- переключение ----------
    def do_switch(self):
        if self._busy:
            return
        self._busy = True
        try:
            text = self._active_selection()
            if text:
                self._replace_text(text)
            else:
                self._switch_last_word()
        except XError as e:
            if self.on_error:
                self.on_error("X11: %s" % e)
        finally:
            self._busy = False

    def _active_selection(self):
        """Текст активного выделения или None.

        Отличаем свежее выделение от старого PRIMARY (Chromium/klipper):
        owner должен быть в одном контексте с фокусом (дерево или WM_CLASS).
        Если фокус в Geany, а PRIMARY держит Chromium clipboard — это старое
        выделение из другого приложения, его брать нельзя.
        """
        owner = self._sel_owner()
        if not owner:
            return None
        focused = self._focused()
        text = self.read_selection("PRIMARY", 0.4)
        if not text or not text.strip():
            return None
        if self._same_context(owner, focused):
            _dbg("active_selection: owner=%r focused=%r text=%r"
                 % (owner, focused, text))
            return text
        _dbg("active_selection: skip (owner %r not same context as focused %r)"
             % (owner, focused))
        return None


    def _switch_last_word(self):
        """Выделить Ctrl+Shift+Left и заменить раскладку последнего слова.

        Свежесть PRIMARY определяется фактом его изменения после combo:
        если owner/текст изменились — combo сработал, выделение свежее.
        Проверка _same_context здесь не нужна и ломает работу в приложениях,
        где owner PRIMARY — не то же окно, что focused (дочернее/служебное).
        """
        pre_owner = self._sel_owner()
        pre_text = self.read_selection("PRIMARY", 0.5) if pre_owner else None
        _dbg("last_word: pre_owner=%r pre_text=%r" % (pre_owner, pre_text))

        self._combo([X.ControlMask, X.ShiftMask], self._kc("Left"))
        time.sleep(0.30)

        post_owner = self._sel_owner()
        text = self.read_selection("PRIMARY", 0.5)
        _dbg("last_word: post_owner=%r post_text=%r" % (post_owner, text))

        if not text or not text.strip():
            return

        # PRIMARY не изменился — combo не создал свежего выделения.
        if pre_text == text:
            _dbg("last_word: skip (stale PRIMARY unchanged)")
            return

        # Sanity: явно чужое содержимое (старая команда из буфера и т.п.).
        if len(text) > 200 or "\n" in text:
            _dbg("last_word: skip (text too long / multi-line)")
            return

        self._replace_text(text)


    def _replace_text(self, text):
        lead = text[:len(text) - len(text.lstrip())]
        trail = text[len(text.rstrip()):]
        body = text.strip()
        if not body:
            return
        new = transform(body)
        self._press_key(self._kc("Delete"))
        self.type_text(lead + new + trail)

    # ---------- печать текста ----------
    def type_text(self, text):
        if not text:
            return
        try:
            xkb = self._xkb_conn()
        except Exception:
            xkb = None
        orig = xkb.get_group() if xkb else None
        target = None
        if xkb and self._layouts:
            name = "ru" if has_cyrillic(text) else "us"
            if name in self._layouts:
                target = self._layouts.index(name)
        changed = None not in (target, orig) and target != orig
        if changed:
            xkb.lock_group(target)
            time.sleep(0.03)
        try:
            for ch in text:
                self._type_char(ch)
        finally:
            if changed:
                xkb.lock_group(orig)
                time.sleep(0.03)

    def _type_char(self, ch):
        us = to_latin(ch)
        code = ord(us)
        if code < 32 or code > 126:
            return
        kc = self.dpy.keysym_to_keycode(code)
        if not kc:
            return
        shift = self._shift_level(kc, code)
        if shift:
            xtest.fake_input(self.dpy, X.KeyPress, self._kc("Shift_L"))
        xtest.fake_input(self.dpy, X.KeyPress, kc)
        self.dpy.sync()
        time.sleep(0.004)
        xtest.fake_input(self.dpy, X.KeyRelease, kc)
        if shift:
            xtest.fake_input(self.dpy, X.KeyRelease, self._kc("Shift_L"))
        self.dpy.sync()

    def _shift_level(self, kc, keysym_code):
        for lvl in range(6):
            try:
                ks = self.dpy.keycode_to_keysym(kc, lvl)
            except Exception:
                break
            if ks == keysym_code:
                return lvl in (1, 3)
        return False

    # ---------- чтение выделения ----------
    def read_selection(self, selname="PRIMARY", timeout=0.4):
        sel = self.dpy.intern_atom(selname)
        prop = self.dpy.intern_atom("PUPSHIFT_DATA")
        for tname in ("UTF8_STRING", "STRING", "COMPOUND_TEXT"):
            target = self.dpy.intern_atom(tname)
            try:
                self.sel_win.convert_selection(sel, target, prop, X.CurrentTime)
            except XError:
                return None
            self.dpy.flush()
            data = self._wait_notify(prop, target, timeout)
            if data:
                return data
        return None

    def _wait_notify(self, prop, target, timeout):
        deadline = time.time() + timeout
        while time.time() < deadline:
            for ev in self._pump(0.05):
                if (ev.type == X.SelectionNotify
                        and getattr(ev.requestor, "id", ev.requestor) == self.sel_win.id):
                    if not ev.property:
                        return None
                    return self._read_prop(prop, target)
        return None

    def _read_prop(self, prop, target):
        r = self.sel_win.get_property(prop, target, 0, 1 << 20)
        try:
            self.sel_win.delete_property(prop)
        except XError:
            pass
        if r is None:
            return None
        val = r.value
        if isinstance(val, list):
            val = bytes(bytearray(val))
        if isinstance(val, str):
            return val
        try:
            return val.decode("utf-8")
        except UnicodeDecodeError:
            return val.decode("latin-1")

    # ---------- окна и владельцы ----------
    def _sel_owner(self, selname="PRIMARY"):
        try:
            w = self.dpy.get_selection_owner(self.dpy.intern_atom(selname))
        except XError:
            return None
        if w is None:
            return None
        wid = getattr(w, "id", w)
        if not wid:
            return None
        return wid

    def _focused(self):
        try:
            f = self.dpy.get_input_focus().focus
        except XError:
            return None
        return getattr(f, "id", f)

    def _parent_of(self, wid):
        """id родителя окна wid (или None)."""
        try:
            w = self.dpy.create_resource_object("window", wid)
            parent = w.query_tree().parent
        except XError:
            return None
        if parent is None:
            return None
        return getattr(parent, "id", parent)

    def _chain(self, wid):
        """[wid, parent, ..., root] с ограничением глубины."""
        chain = []
        w = wid
        for _ in range(32):
            if not w:
                break
            chain.append(w)
            if w == self.root.id:
                break
            w = self._parent_of(w)
        return chain

    def _related(self, wid1, wid2):
        """True, если окна связаны (общий предок, кроме корня)."""
        if not wid1 or not wid2:
            return False
        if wid1 == wid2:
            return True
        c1 = set(self._chain(wid1)) - {self.root.id}
        c2 = set(self._chain(wid2)) - {self.root.id}
        return bool(c1 & c2)

    def _parent_of(self, wid):
        """id родителя окна wid (или None)."""
        try:
            w = self.dpy.create_resource_object("window", wid)
            parent = w.query_tree().parent
        except XError:
            return None
        if parent is None:
            return None
        return getattr(parent, "id", parent)

    def _chain(self, wid):
        """[wid, parent, ..., root] с ограничением глубины."""
        chain = []
        w = wid
        for _ in range(32):
            if not w:
                break
            chain.append(w)
            if w == self.root.id:
                break
            w = self._parent_of(w)
        return chain

    def _related(self, wid1, wid2):
        """True, если окна связаны (общий предок, кроме корня)."""
        if not wid1 or not wid2:
            return False
        if wid1 == wid2:
            return True
        c1 = set(self._chain(wid1)) - {self.root.id}
        c2 = set(self._chain(wid2)) - {self.root.id}
        return bool(c1 & c2)

    def _wm_class(self, wid):
        """WM_CLASS окна или ближайшего предка (обычно только у top-level)."""
        for w_id in self._chain(wid):
            try:
                w = self.dpy.create_resource_object("window", w_id)
                cls = w.get_wm_class()
                if cls:
                    return cls
            except XError:
                continue
        return None

    def _same_context(self, wid1, wid2):
        """True, если окна связаны по дереву или WM_CLASS.

        WM_CLASS нужен для Chromium: окно чата и служебное окно
        «Chromium clipboard» не связаны по дереву (оба top-level),
        но имеют одинаковый WM_CLASS.
        """
        if not wid1 or not wid2:
            return False
        if wid1 == wid2:
            return True
        related = self._related(wid1, wid2)
        c1 = self._wm_class(wid1)
        c2 = self._wm_class(wid2)
        match = c1 is not None and c2 is not None and c1 == c2
        _dbg("same_context: %r vs %r related=%r wm1=%r wm2=%r match=%r"
             % (wid1, wid2, related, c1, c2, match))
        return related or match


    def _top(self, wid):
        if not wid:
            return None
        try:
            w = self.dpy.create_resource_object("window", wid)
        except XError:
            return None
        for _ in range(20):
            try:
                tree = w.query_tree()
            except XError:
                return None
            parent = tree.parent
            if parent is None or getattr(parent, "id", None) == self.root.id:
                return w.id
            w = parent
        return getattr(w, "id", None)

    # ---------- низкоуровневые нажатия ----------
    def _kc(self, name):
        return self.dpy.keysym_to_keycode(XK.string_to_keysym(name))

    def _mod_kc(self, mask):
        name = {X.ControlMask: "Control_L", X.ShiftMask: "Shift_L",
                X.Mod1Mask: "Alt_L", X.Mod4Mask: "Super_L"}.get(mask)
        return self._kc(name) if name else 0

    def _combo(self, mod_masks, kc):
        for m in mod_masks:
            xtest.fake_input(self.dpy, X.KeyPress, self._mod_kc(m))
        xtest.fake_input(self.dpy, X.KeyPress, kc)
        self.dpy.sync()
        time.sleep(0.02)
        xtest.fake_input(self.dpy, X.KeyRelease, kc)
        for m in reversed(mod_masks):
            xtest.fake_input(self.dpy, X.KeyRelease, self._mod_kc(m))
        self.dpy.sync()

    def _press_key(self, kc):
        xtest.fake_input(self.dpy, X.KeyPress, kc)
        self.dpy.sync()
        time.sleep(0.01)
        xtest.fake_input(self.dpy, X.KeyRelease, kc)
        self.dpy.sync()